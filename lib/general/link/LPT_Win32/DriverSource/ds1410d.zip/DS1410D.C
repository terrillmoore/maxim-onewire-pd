/////////////////////////////////////////////////////////////////////////////
//
//  DS1410D.C                                { Ver 3.00  11/08/2002 }
//
//    Windows NT driver for the DS1410E parallel port resident adapter 
//
//  Revisions
//      1.00 -> 1.01   Bit wiggling stuff converted to DS1410D operation
//                   only.
// 
//      1.01 -> 2.00   Added code for support of the DS1410E with EPP
//                   passthru mode. DS1410D adapters are still supported. 
//
//      2.00 -> 2.50   Added block I/O functionality to minimize context
//                   switching for CiB communication. Also added a fast
//                   access which should only be used when communicating
//                   in overdrive !!!
// 
//      2.50 -> 2.51   Added check overdrive function to test overdrive
//                   without affecting the state of the overdrive FF in  
//                   DS1481. Also added a fast byte routine witch bangs
//                   8 bits without restoring the old IRQL. This should
//                   only be used in overdrive mode !!!
//
//      2.51 -> 2.52   Added dynamic unloading capability.
//
//      2.52 -> 2.53   Left 1 of the 6 high order data bits low after
//                  a docomm time slot to avoid problems with anything
//                  that grounds 14. This was the case up until ver 2.5
//                  at which time the lines were all driven high to help
//                  power the CiB.
//
//      2.53 -> 2.54   Change all bit-wiggling code to ensure that we can
//                  speak to a DS1410E even if the printer is grounding
//                  pin 14.
//
//      2.54 -> 3.00   Re-wrote DriverEntry section of driver to allow 
//                  finding of any parallel port, including PCI add-on
//                  parallel ports.
//
//    Debugging Info
//    ==============
//      In order to view the DebugPrint messages in this driver please do 
//      the following:
//     
//      1) Obtain DebugPrint.c and DebugPrint.h from SourceSafe and 
//         place them in your working directory.  If you do not have a 
//         copy, you can purchase your own here:  http://www.phdcc.com/debugprint/
//      2) Change the "Sources" file to build with DebugPrint.c.  Make 
//         sure you substitute the correct drive and path names 
//         where appropriate.  You might want to create a "DebugSources" file with 
//         the info below and when you need debug info, then rename 
//         the file to "Sources".
//
//          Example Sources file:
//
//          TARGETNAME=DS1410D
//          TARGETPATH=F:\Work\Release
//          TARGETTYPE=DRIVER
//          INCLUDES=F:\NTDDK\inc
//          SOURCES=ds1410d.c \
//                  DebugPrint.c \
//
//      3)  Open DebugPrint.h and set:
//          #define DEBUGPRINT 1	//(Set to 1 to do DebugPrints in free version of OS)
//
//      4)  Open ds1410d.h and uncomment the #define DO_DEBUG line.
//
//      5)  Uncomment DebugPrint calls in the driver, making sure that DebugPrintInit 
//          is in the DriverEntry subroutine, and DebugPrintClose() is in the 
//          DOWDriverUnload subroutine.
//
//      6)  Make sure you install the DebugPrint Monitor program and the DebugPrint.sys driver. 
//          To install the DebugPrint.sys driver, do the following:
//          
//          a)  Double-click the "Add New Hardware" applet wizard found in "Control Panel".
//          b)  Click next two times, select "No, I want to select hardware from a list" and
//              click next.
//          c)  Select "Other devices" and click Next.  Click "Have Disk..." and browse to the path
//              of the installation INF file and click "OK".  Follow the instructions the rest of 
//              the way... (Choose "free" build).
//
//    Using DebugPrint functions:
//    ===========================
//      1)  For just a single string, use "DebugPrintMsg".  For printing out other 
//          info, including variables, use the "DebugPrint" function call.
//      2)  Here is the list of DebugPrint format specifiers:
//          %c       char
//          %C       Wide character
//          %d, %i   Signed integer in decimal
//          %D       __int64 in decimal
//          %I       IRP major and minor codes
//          %L       LARGE_INTEGER in hexadecimal of type LARGE_INTEGER
//          %s       NULL-terminated ANSI character string
//          %S       NULL-terminated Wide character string
//          %T       UNICODE_STRING  (must use pointer!--PUNICODE_STRING)
//          %u       ULONG in decimal
//          %x       ULONG in hexadecimal
//
//
//  Copyright (C) 1994-2002 Dallas Semiconductor MAXIM Corporation. 
//  All rights Reserved. Printed in U.S.A.
//  This software is protected by copyright laws of
//  the United States and of foreign countries.
//  This material may also be protected by patent laws of the United States 
//  and of foreign countries.
//  This software is furnished under a license agreement and/or a
//  nondisclosure agreement and may only be used or copied in accordance
//  with the terms of those agreements.
//  The mere transfer of this software does not imply any licenses
//  of trade secrets, proprietary technology, copyrights, patents,
//  trademarks, maskwork rights, or any other form of intellectual
//  property whatsoever. Dallas Semiconductor retains all ownership rights.
//
/////////////////////////////////////////////////////////////////////////////

#include <stddef.h>
#include "ntddk.h"

#include "ds1410d.h"

#define NAND_MASK 0xAB
#define CONTROL_REG_MASK 0x1F

#define PAR_PORT_NAME		L"\\Device\\ParallelPort"

/////////////////////////////////////////////////////////////////////////////
//
//    Create Device Object, Create symbolic link, then register driver 
// entry points.
//
NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject,  
                     IN PUNICODE_STRING RegistryPath)
{
   ULONG		         DeviceNumber;       // 0-based number in order given from operating system
   NTSTATUS	             status;             // Return value for function
   STRING                AnsiUserName;       // Ansi user name
   STRING                AnsiObjectName;     // Ansi object name
   UNICODE_STRING        UserName;           // Unicode user name
   UNICODE_STRING        ObjectName;         // Unicode object name
   PDEVICE_OBJECT        deviceObject;       // Pointer to device object
   PUCHAR                ReturnAddress;      // Return value of memory mapped address
   PDOW_DEVICE_EXTENSION deviceExtension;    // Pointer to extension
   ULONG                 PortsFound;         // Number of parallel ports found
   BOOLEAN               ConflictDetected; 

   WCHAR				 ParPortDeviceBuffer[46]; // Help to instantiate the parallel port unicode string
   WCHAR				 NumberBuffer[6];         // Help to instantiate the parallel port number unicode string

   UNICODE_STRING		 uniParPortDevice = {0, sizeof(ParPortDeviceBuffer)/sizeof(WCHAR), ParPortDeviceBuffer};
   UNICODE_STRING		 uniNumber = {0, sizeof(NumberBuffer)/sizeof(WCHAR), NumberBuffer};

   PHYSICAL_ADDRESS      pa;

   KEVENT                         event;
   PIRP                           irp;
   IO_STATUS_BLOCK                ioStatus;
   PARALLEL_PORT_INFORMATION      ParPortInfo;
   MORE_PARALLEL_PORT_INFORMATION MoreParPortInfo;
   PFILE_OBJECT	                  ParPortFileObject;
   PDEVICE_OBJECT                 ParPortDeviceObject;

   #ifdef DO_DEBUG
      DebugPrintInit("DS1410D free");
      DebugPrintMsg("Release V3.00:  Initializing DS1410D.SYS driver");
   #endif

   // Get number of parallel ports (parallel devices that have device objects created 
   // to represent them by drivers as they are loaded by the OS).

   PortsFound = IoGetConfigurationInformation()->ParallelCount;
   if (PortsFound > MAX_PAR_NUM) PortsFound = MAX_PAR_NUM;  // prevent possible buffer overrun

   #ifdef DO_DEBUG
      DebugPrint("DriverEntry Loading. System has %d Parallel Ports",PortsFound);
   #endif

   RtlInitString(&AnsiUserName, "\\DosDevices\\LPT9"); 
   RtlInitString(&AnsiObjectName, "\\Device\\DOW0");

   // Convert user name to unicode string
   status = RtlAnsiStringToUnicodeString(&UserName, 
                                         &AnsiUserName,
                                         TRUE);
   // Convert object name to unicode string 
   if (status == STATUS_SUCCESS)      
       status = RtlAnsiStringToUnicodeString(&ObjectName, 
                                             &AnsiObjectName,
                                             TRUE);

   // Let's create the DS1410E Device
   status = IoCreateDevice(DriverObject,				  // DriverObject
    					   sizeof(DOW_DEVICE_EXTENSION),  // DeviceExtensionSize
						   &ObjectName,				      // DeviceName
						   FILE_DEVICE_PARALLEL_PORT,	  // DeviceType
						   0,							  // DeviceCharacteristics
						   TRUE,						  // Exclusive, only 1 thread at a time pleas.
						   &deviceObject);				  // *DeviceObject

   #ifdef DO_DEBUG
      DebugPrint("DS1410D.SYS: Create Device, DriverObject %x, DeviceObject %x",DriverObject,deviceObject);
   #endif

   if(!NT_SUCCESS(status)) 
   {
      #ifdef DO_DEBUG
    	DebugPrint("DS1410D.SYS: Cannot Create Device - IoCreateDevice Failed NTSTATUS %x",status);
      #endif
	  return status;
   }

   deviceExtension = deviceObject->DeviceExtension;

   RtlZeroMemory(deviceExtension, sizeof(DOW_DEVICE_EXTENSION));

   deviceExtension->DeviceObject = deviceObject;

   // if deviceObject->Flags does not have DO_BUFFERED_IO, 1-Wire will not function!
   deviceObject->Flags |= DO_BUFFERED_IO;


   for(DeviceNumber=0; DeviceNumber<PortsFound; DeviceNumber++)
   {
	    // Each parallel port has a device name equivalent to
	    // "\Device\ParallelPortX" where x is 0, 1, 2, 3, etc.

	    // Create unicode string from DeviceNumber and then 
	    // append it to the unicode string of "\Device\ParallelPort."
	    // This gives "\Device\ParallelPort0", "\Device\ParallelPort1", etc.
        RtlIntegerToUnicodeString(DeviceNumber, 10, &uniNumber);
        
        #ifdef DO_DEBUG
		  DebugPrint("uniNumber:  %T", &uniNumber);
        #endif

        uniParPortDevice.Length = 0;
        RtlAppendUnicodeToString(&uniParPortDevice, PAR_PORT_NAME);
        
        #ifdef DO_DEBUG
		   DebugPrint("ParPortName base string:  %T", &uniParPortDevice);
        #endif

		RtlAppendUnicodeStringToString(&uniParPortDevice, &uniNumber);

        #ifdef DO_DEBUG
		   DebugPrint("ParPortName:  %T", &uniParPortDevice);
        #endif

		deviceExtension->pn = (UCHAR) DeviceNumber;

        // returns a pointer to the parallel port file object and 
		// device object represented by "\Device\ParallelPortX"
 		status = IoGetDeviceObjectPointer(&uniParPortDevice, 
										  FILE_READ_ATTRIBUTES,
										  &ParPortFileObject,
										  &ParPortDeviceObject);

		// The rest of this code calls the "next lower driver", in this case 
		// parport.sys?? and retrieves two specific structs:
		// PARALLEL_PORT_INFORMATION and MORE_PARALLEL_PORT_INFORMATION
		if (!NT_SUCCESS(status)) 
		{
	       #ifdef DO_DEBUG
		      DebugPrint("DS1410D.SYS: DriverEntry Cannot Open ParPort, ParallelPort%d",DeviceNumber);
           #endif
		   IoDeleteDevice(ParPortDeviceObject);
		   status = STATUS_SUCCESS;
		   break;
		}

		ObReferenceObjectByPointer(	&ParPortDeviceObject,FILE_READ_ATTRIBUTES,
									NULL,KernelMode);
		ObDereferenceObject(&ParPortFileObject);
    
		KeInitializeEvent(&event, NotificationEvent, FALSE);

		// Make our i/o request packet (IRP) for a specific parallel port device
		// and return PARALLEL_PORT_INFORMATION
		irp = IoBuildDeviceIoControlRequest(
											IOCTL_INTERNAL_GET_PARALLEL_PORT_INFO,
											ParPortDeviceObject,
											NULL, 
											0, 
											&ParPortInfo,
											sizeof(PARALLEL_PORT_INFORMATION),
											TRUE, 
											&event, 
											&ioStatus);

		if (!irp) 
		{
            #ifdef DO_DEBUG
			   DebugPrintMsg("DS1410D.SYS: GET_PARALLEL_PORT_INFO Insufficent Resources for IoBuildDeviceIoControlRequest");
            #endif
            IoDeleteDevice(ParPortDeviceObject);
			status = STATUS_INSUFFICIENT_RESOURCES;
			break;
		}

		// Send IRP here
		status = IoCallDriver(ParPortDeviceObject, irp);


		if (!NT_SUCCESS(status)) 
		{
            #ifdef DO_DEBUG
			   DebugPrintMsg("DS1410D.SYS: GET_PARALLEL_PORT_INFO Unexpected Failure in IoCallDriver");
            #endif
			IoDeleteDevice(ParPortDeviceObject);
			status = STATUS_INSUFFICIENT_RESOURCES;
			break;
		}

        // Wait until IRP comes back
		status = KeWaitForSingleObject(&event, Executive, KernelMode, FALSE, NULL);

		if (!NT_SUCCESS(status))
		{
            #ifdef DO_DEBUG
			   DebugPrintMsg("DS1410D.SYS: GET_PARALLEL_PORT_INFO Unexpected Failure in KeWaitForSingleObject");
            #endif
			IoDeleteDevice(ParPortDeviceObject);
			break;
		}

        #ifdef DO_DEBUG
		   DebugPrint("DS1410D.SYS: Parallel Port at Address 0x%x and spans %d bytes",(ULONG)ParPortInfo.Controller,ParPortInfo.SpanOfController);
        #endif

		deviceExtension->PortAddress = (ULONG)ParPortInfo.Controller;

		// Get Interrupt Information
		KeInitializeEvent(&event, NotificationEvent, FALSE);

		// Make our i/o request packet (IRP) for a specific parallel port device
		// and return MORE_PARALLEL_PORT_INFORMATION
		irp = IoBuildDeviceIoControlRequest(
											IOCTL_INTERNAL_GET_MORE_PARALLEL_PORT_INFO,
											ParPortDeviceObject,
											NULL, 
											0, 
											&MoreParPortInfo,
											sizeof(MORE_PARALLEL_PORT_INFORMATION),
											TRUE, 
											&event, 
											&ioStatus);

		if (!irp) 
		{
            #ifdef DO_DEBUG
			   DebugPrintMsg("DS1410D.SYS: GET_MORE_PARALLEL_PORT_INFO Insufficent Resources for IoBuildDeviceIoControlRequest");
            #endif
			IoDeleteDevice(ParPortDeviceObject);
			status = STATUS_INSUFFICIENT_RESOURCES;
			break;
		}

		// Send IRP out
		status = IoCallDriver(ParPortDeviceObject, irp);

		if (!NT_SUCCESS(status)) 
		{
            #ifdef DO_DEBUG
			   DebugPrintMsg("DS1410D.SYS: GET_MORE_PARALLEL_PORT_INFO Unexpected Failure in IoCallDriver");
            #endif
			IoDeleteDevice(ParPortDeviceObject);
			break;
		}
        // Wait for info to come back
		status = KeWaitForSingleObject(&event, Executive, KernelMode, FALSE, NULL);

		if (!NT_SUCCESS(status)) 
		{
			#ifdef DO_DEBUG
			   DebugPrintMsg("DS1410D.SYS: GET_MORE_PARALLEL_PORT_INFO Unexpected Failure in KeWaitForSingleObject");
            #endif
			IoDeleteDevice(ParPortDeviceObject);
			break;
		}

        #ifdef DO_DEBUG
		   DebugPrint("DS1410D.SYS: InterfaceType 0x%x",MoreParPortInfo.InterfaceType);
		   DebugPrint("DS1410D.SYS: BusNumber 0x%x",MoreParPortInfo.BusNumber);
		   DebugPrint("DS1410D.SYS: Interrupt Vector 0x%x",MoreParPortInfo.InterruptVector);
		   DebugPrint("DS1410D.SYS: Interrupt Affinity 0x%x",MoreParPortInfo.InterruptAffinity);
		   DebugPrint("DS1410D.SYS: Interrupt Mode 0x%x",MoreParPortInfo.InterruptMode);
        #endif

		deviceExtension->InterfaceType = MoreParPortInfo.InterfaceType;
		deviceExtension->BusNumber = MoreParPortInfo.BusNumber;
		deviceExtension->Vector = MoreParPortInfo.InterruptVector;
		deviceExtension->InterruptMode = MoreParPortInfo.InterruptMode;
		deviceExtension->Affinity = MoreParPortInfo.InterruptAffinity;
		pa.HighPart=0;
		pa.LowPart=(ULONG)ParPortInfo.Controller;

		// Memory map this thing
		ParPortInfo.SpanOfController = 3;
		ReturnAddress = DOWGetMmAddress(MoreParPortInfo.InterfaceType,
		                MoreParPortInfo.BusNumber,
						pa,
						(ULONG)ParPortInfo.SpanOfController,
						TRUE,
						&deviceExtension->UnMapRegisters);

		deviceExtension->Controller[DeviceNumber] = ReturnAddress; 
        #ifdef DO_DEBUG
           DebugPrint("DeviceNumber = %i, ReturnAddress = %x", DeviceNumber, ReturnAddress);
        #endif
		// Store controller span in device extension
		deviceExtension->SpanOfController = ParPortInfo.SpanOfController;
        #ifdef DO_DEBUG
           DebugPrint("Port%u is at address:  %x", DeviceNumber, deviceExtension->Controller[DeviceNumber]);
        #endif

   } // End for loop looking for parallel ports


   if (PortsFound > 0)   
   {
      #ifdef DO_DEBUG
         DebugPrint("Ports found:  %u", PortsFound);
      #endif

      // Save # of ports found
      deviceExtension->ParNumFound = (UCHAR) PortsFound;

      #ifdef DO_DEBUG
         DebugPrint("Port0 is at address:  %x", deviceExtension->Controller[0]);
      #endif

      // Was mapping of at least 1 port good ?
      if (!deviceExtension->Controller[0])
	  {
         status = STATUS_NO_SUCH_DEVICE;
         #ifdef DO_DEBUG
		    DebugPrint("   Could not find 1 good port!");
         #endif
	  }
      // Create symbolic link
      if (status == STATUS_SUCCESS)                 
      {
         deviceExtension->pn = 0;                        

         status = IoCreateUnprotectedSymbolicLink(&UserName, &ObjectName);

         // Report resource usage to registry
         IoReportResourceUsage(NULL,   
                               DriverObject,
                               NULL,
                               0,
                               deviceObject,
                               NULL,
                               0,
                               FALSE,
                               &ConflictDetected);

         // Not much chance of this since were not claiming an interrupt
         if (ConflictDetected) 
            status = STATUS_INSUFFICIENT_RESOURCES;
	  }
   }

   // Release memory held by UserName
   RtlFreeUnicodeString(&UserName);  
   // Release memory held by ObjectName
   RtlFreeUnicodeString(&ObjectName); 
   // Register driver entry points
   if (status == STATUS_SUCCESS)               
   {
      DriverObject->MajorFunction[IRP_MJ_WRITE]          = DS1410XDispatch;
      DriverObject->MajorFunction[IRP_MJ_READ]           = DS1410XDispatch;
      DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DS1410XDispatch;
      DriverObject->MajorFunction[IRP_MJ_CREATE]         = DS1410XDispatch;
      DriverObject->MajorFunction[IRP_MJ_CLOSE]          = DS1410XDispatch;
      DriverObject->DriverUnload                         = DOWDriverUnload;
   }

   // return result to the I/O manager
   return status;                      
}


/////////////////////////////////////////////////////////////////////////////
//
//    Get a memory mapped address for the HAL to use for our bit-banging
// needs.
//
PVOID DOWGetMmAddress(IN INTERFACE_TYPE BusType,
                      IN ULONG BusNumber,
                      PHYSICAL_ADDRESS IoAddress,
                      ULONG NumberOfBytes,
                      ULONG AddressSpace,
                      PBOOLEAN UMap)
{
   PHYSICAL_ADDRESS TranslatedAddress;
   PVOID address;

   #ifdef DO_DEBUG
      DebugPrint(" DOWGetMmAddress InterfaceType=%d",BusType);
      DebugPrint(" DOWGetMmAddress BusNumber=%u",BusNumber);
      DebugPrint(" DOWGetMmAddress IoAddress=%d",IoAddress);
      DebugPrint(" DOWGetMmAddress NumberOfBytes=%u",NumberOfBytes);
      DebugPrint(" DOWGetMmAddress AddressSpace=%u",AddressSpace);
   #endif

   if (!HalTranslateBusAddress(BusType,
                               BusNumber,
                               IoAddress,
                               &AddressSpace,
                               &TranslatedAddress))
   {
      AddressSpace = 1;
   }

   // If address not in virtual space, put it there
   if (!AddressSpace)         
   {
      address = MmMapIoSpace(TranslatedAddress, NumberOfBytes, FALSE);
      *UMap   = (address ? TRUE : FALSE);
   }
   else 
   {
      address = (PVOID) TranslatedAddress.LowPart;
      *UMap   = FALSE;
   }
   if (!address) 
   {
      #ifdef DO_DEBUG
	     DebugPrintMsg(" DOWGetMmAddress is NULL!"); 
      #endif
   }
   else 
   {
	  #ifdef DO_DEBUG
	     DebugPrintMsg(" DOWGetMmAddress is not NULL");
      #endif
   }
   
   return address;
}

/////////////////////////////////////////////////////////////////////////////
//
//    Undo all the stuff done at driver initialization. 
//
VOID DOWDriverUnload(IN PDRIVER_OBJECT DOWDriverObject)
{
   STRING         AnsiObjectName;   // Ansi string object name
   UNICODE_STRING ObjectName;       // Unicode string object name
   PDEVICE_OBJECT CurrentDevice;
   UCHAR          i;

   #ifdef DO_DEBUG
      DebugPrintClose();
   #endif

   RtlInitString(&AnsiObjectName, "\\DosDevices\\LPT9");

   // Convert object name to unicode string 
   RtlAnsiStringToUnicodeString(&ObjectName, 
                                &AnsiObjectName,
                                TRUE);

   // Whack the symbolic link
   IoDeleteSymbolicLink(&ObjectName);

   i = 0;
   while (CurrentDevice = DOWDriverObject->DeviceObject)
   {
      DOWCleanUpDevice(CurrentDevice->DeviceExtension, i++);
      // Undo IoCreateDevice 
      IoDeleteDevice(CurrentDevice);
   }
}

/////////////////////////////////////////////////////////////////////////////
//
//    Unmap translated bus addresses
//
VOID DOWCleanUpDevice(IN PDEVICE_OBJECT DOWDeviceObject, IN UCHAR i)
{
   PDOW_DEVICE_EXTENSION extension = DOWDeviceObject->DeviceExtension;

   if (extension && extension->UnMapRegisters)
   {
   /*
      MmUnmapIoSpace(extension->Controller[i],
                     3); 
                     //extension->SpanOfController); 
   */
   }
}
 
/////////////////////////////////////////////////////////////////////////////
//
//    Commands processed here.
//
NTSTATUS DS1410XDispatch(IN PDEVICE_OBJECT ODevObject, IN PIRP OIrp)
{
   UCHAR              APtr, PN;
   UCHAR              tbit, tbyte, rbyte;
   UCHAR              i;
   ULONG              j;
   NTSTATUS           status;
   PIO_STACK_LOCATION OIrpSp;

   PUCHAR irpBuffer = NULL;
   PDOW_DEVICE_EXTENSION extension = NULL;
   
   // Get pointer to system buffer for I/O
   //PUCHAR 
	   irpBuffer = OIrp->AssociatedIrp.SystemBuffer;
   // Get extension so we can have our globals
   //PDOW_DEVICE_EXTENSION 
	   extension = ODevObject->DeviceExtension;

   OIrpSp = IoGetCurrentIrpStackLocation(OIrp);              

   OIrp->IoStatus.Information = 0L;               
   status = STATUS_SUCCESS;                 
   switch (OIrpSp->MajorFunction)
   {
      // Called by CloseHandle
      case IRP_MJ_CLOSE:  
      break;

      // Called by CreateFile
      case IRP_MJ_CREATE: 
         OIrp->IoStatus.Status= status; 
      break;

      // Called by ReadFile
      case IRP_MJ_READ:   
         if ((OIrpSp->Parameters.Read.ByteOffset.HighPart != 0) ||
             (OIrpSp->Parameters.Read.ByteOffset.LowPart != 0))
         {
            status = STATUS_INVALID_PARAMETER;
         }
         else
         {
            if (OIrpSp->Parameters.Read.Length == extension->CRLen)
            {
               // Send back result of last Write
               for (j = 0; j < extension->CRLen; j++)
                  irpBuffer[j] = extension->CommResult[j];
      
               OIrpSp->Parameters.Read.Length = 0; 
               OIrp->IoStatus.Information = extension->CRLen;     

               OIrp->IoStatus.Status = STATUS_SUCCESS; 
            }
            else
               status = STATUS_INVALID_PARAMETER;
         }
      break;

      // Called by WriteFile
      case IRP_MJ_WRITE:   
         if ((OIrpSp->Parameters.Write.ByteOffset.HighPart != 0) ||
             (OIrpSp->Parameters.Write.ByteOffset.LowPart != 0))
         {
            status = STATUS_INVALID_PARAMETER;
         }
         else
         {
            if (OIrpSp->Parameters.Write.Length >= 2)
            {
               // Default return length 
               extension->CRLen = 1;

               switch (irpBuffer[0])
               {
                  case DO_RESET:                     
                     // Get port number
                     APtr = irpBuffer[1];       

                     // Is this a good # 
                     if (extension->ParNumFound >= APtr)   
                     { 
                        // Set new (0 based) port number 
                        extension->pn = APtr - 1;       

                        // Do a reset
                        extension->CommResult[0] =                  
                           docomm(DOW_RESET, 
                                  extension->Controller[APtr - 1]) ^ 1;

                        // Indicate last port good 
                        extension->GoodPort = TRUE; 
                     }
                     else
                     { 
                        // Indicate last port bad
                        extension->GoodPort = FALSE; 
                        // Fail if invalid port #
                        extension->CommResult[0] = 0;   
                     }
                  break;

                  case DO_BIT:                          
                     // Are we on a valid port
                     if (extension->GoodPort)        
                     {
                        // Get current port number
                        PN = extension->pn;         
                        // Get bit value
                        tbit = irpBuffer[1];      

                        // Do a bit time slot
                        extension->CommResult[0] =          
                           docomm((UCHAR) (tbit ? 0xFF : 0xFE), 
                                           extension->Controller[PN]); 
                     }
                     else
                        extension->CommResult[0] = 1;     
                  break;

                  case DO_BYTE:          
                     // Get byte value
                     tbyte = irpBuffer[1];       
 
                     // See if we are on a valid port
                     if (extension->GoodPort)        
                     {
                        // Get current port number
                        PN = extension->pn;         
                        // Initialize receive byte
                        rbyte = 0;                  
   
                        for (i = 0; i < 8; i++)      
                        {
                           rbyte >>= 1;               
   
                           // Read a bit and or it in
                           rbyte |= (docomm((UCHAR) (tbyte & 1 ? 0xFF : 0xFE), 
                                             extension->Controller[PN]) << 7); 
   
                           // Position transmit byte
                           tbyte >>= 1;              
                        }
                     }
                     else
                        rbyte = tbyte; // If bad port return byte received

                     // Store received byte
                     extension->CommResult[0] = rbyte;     
                  break;

                  case DO_BLOCK:
                     // See if we are on a valid port
                     if (extension->GoodPort)        
                     {
                        // Get current port number
                        PN = extension->pn;         

                        // Save byte count
                        extension->CRLen = irpBuffer[1];
                        for (j = 0; j < extension->CRLen; j++)
                        {
                           extension->CommResult[j] = 
                                        FastByte(irpBuffer[j+2], 
                                                 extension->Controller[PN]);
                        }
                     }
                     else
                     {
                        for (i = 0; i < irpBuffer[1]; i++)
                           extension->CommResult[i] = irpBuffer[i+2];
                     }
                  break;

                  case FAST_ACCESS:
                     extension->CommResult[0] = FALSE;

                     if (extension->GoodPort)        
                     {
                        // Get current port number
                        PN = extension->pn;         
   
                        if (!docomm(DOW_RESET, extension->Controller[PN]))
                        {
                           // Weak access succeeds if presence is detected
                           extension->CommResult[0] = TRUE;
                           FastByte(DOW_ACCESS, extension->Controller[PN]);

                           for (i = 0; i < 8; i++)      
                           {
                              FastByte(irpBuffer[i+1], 
                                       extension->Controller[PN]);
                           }
                        }
                     }
                  break;

                  case CHECK_OVERDRIVE:
                     // Are we on a valid port
                     if (extension->GoodPort)        
                     {
                        // Get current port number
                        PN = extension->pn;         

                        // Send toggle overdrive signal 
                        extension->CommResult[0] =          
                           CheckOD(extension->Controller[PN]); 
                     }
                     else
                        extension->CommResult[0] = 0;     
                  break;

                  case TOGGLE_OVERDRIVE:
                     // Are we on a valid port
                     if (extension->GoodPort)        
                     {
                        // Get current port number
                        PN = extension->pn;         

                        // Send toggle overdrive signal 
                        extension->CommResult[0] =          
                           dotoggle(extension->Controller[PN]); 
                     }
                     else
                        extension->CommResult[0] = 0;     
                  break;

                  case TOGGLE_PASSTHRU:
                     // Are we on a valid port
                     if (extension->GoodPort)        
                     {
                        // Get current port number
                        PN = extension->pn;         

                        // Send 4 overdrive toggles
                        for (i = 0; i < 4; i++)
                           dotoggle(extension->Controller[PN]); 

                        extension->CommResult[0] = 1;
                     }
                     else
                        extension->CommResult[0] = 0;     
                  break;

                  case CHECK_BRICK:
                     // Are we on a valid port
                     if (extension->GoodPort)        
                     {
                        // Get current port number
                        PN = extension->pn;         

                        // Do a reset to invoke last part detect
                        docomm(DOW_RESET, extension->Controller[PN]);

                        // Send brick check sequence 
                        extension->CommResult[0] =          
                           docheck(extension->Controller[PN]); 
                     }
                     else
                        extension->CommResult[0] = 0;     
                  break;

                  case SET_PORT:                     
                     // Get port number
                     APtr = irpBuffer[1];       

                     // Is this a good # 
                     if (extension->ParNumFound >= APtr)   
                     { 
                        // Set new port number (0 based)
                        extension->pn = APtr - 1;       
                        // Indicate last port good 
                        extension->GoodPort = TRUE; 
                        
                        extension->CommResult[0] = 1;   
                     }
                     else
                     { 
                        // Indicate last port bad
                        extension->GoodPort = FALSE; 
                        // Fail if invalid port #
                        extension->CommResult[0] = 0;   
                     }
                  break;
               }
      
               OIrpSp->Parameters.Write.Length = 0; 
               OIrp->IoStatus.Information      = 2L;     
               OIrp->IoStatus.Status           = STATUS_SUCCESS; 
            }
            else
               status = STATUS_INVALID_PARAMETER; // Wrong number of bytes
         }

      break;

      default:
         status = STATUS_INVALID_PARAMETER; // Not an entry we support
   }

   // Wer'e done with this IRP
   IoCompleteRequest(OIrp, IO_NO_INCREMENT);        
   return status;
}

/////////////////////////////////////////////////////////////////////////////
//
//   Send toggle overdrive sequence to DS1481. 
//
UCHAR dotoggle(PUCHAR PortAddr)
{
   UCHAR bpap2;                            
   UCHAR BitVal;                          
   KIRQL oldIrql; // Current irterrupt request level 
   UCHAR ControlRegGlobal;

   // Keep spooler from running during a time slot
   KeRaiseIrql(CLOCK2_LEVEL, &oldIrql);        

   // 
   // Added in 2.54 to ensure ENI\ is high when D/CLK\ and RES\ are 
   // set to their initial state
   //
   WRITE_PORT_UCHAR(PortAddr, 0xDC);    
   KeStallExecutionProcessor(2);   

   // Set initial state of data lines for toggle overdrive
   WRITE_PORT_UCHAR(PortAddr, 0xFC);    

   KeStallExecutionProcessor(2);   

   // Save control register
   //bpap2 = (READ_PORT_UCHAR(PortAddr + 2) | 0x04) & 0x1C;        
   ControlRegGlobal = (READ_PORT_UCHAR(PortAddr + 2));
   bpap2 = (ControlRegGlobal | 0x04) & 0x1C;

   // Start time slot
   WRITE_PORT_UCHAR(PortAddr + 2, (UCHAR) (bpap2 | 0x02));  

   KeStallExecutionProcessor(4);                             

   BitVal = ((READ_PORT_UCHAR(PortAddr + 1) ^ 0x80) & 0x90) ? TRUE : FALSE;
   
   // Drive ENI\ back high
   //WRITE_PORT_UCHAR(PortAddr + 2, (UCHAR) (bpap2 & 0xFD));    

   // Drive a couple to our extra cs lines low 
   WRITE_PORT_UCHAR(PortAddr, NAND_MASK);    

   KeStallExecutionProcessor(2);              

   WRITE_PORT_UCHAR(PortAddr+2, (UCHAR) (ControlRegGlobal &CONTROL_REG_MASK));
   // let spooler back in
   KeLowerIrql(oldIrql);                                
   // Give 14 a little time to rise 
   KeStallExecutionProcessor(5);              

   return BitVal;                            
}

/////////////////////////////////////////////////////////////////////////////
//
//   Check to see if attached DS1481s are in overdrive. This function does
// not alter the state of the overdrive FF.
//
UCHAR CheckOD(PUCHAR PortAddr)
{
   UCHAR bpap2;                            
   KIRQL oldIrql; 
   int   i;
   UCHAR Busy      = FALSE;
   UCHAR OverDrive = FALSE;
   UCHAR ControlRegGlobal;


   // Keep spooler from running during a time slot
   KeRaiseIrql(CLOCK2_LEVEL, &oldIrql);        

   // 
   // Added in 2.54 to ensure ENI\ is high when D/CLK\ and RES\ are 
   // set to their initial state
   //
   WRITE_PORT_UCHAR(PortAddr, 0xDF);    
   KeStallExecutionProcessor(2);   

   // Set initial state of data lines
   WRITE_PORT_UCHAR(PortAddr, 0xFF);    

   // Save control register
   //bpap2 = (READ_PORT_UCHAR(PortAddr + 2) | 0x04) & 0x1C;        
   ControlRegGlobal = (READ_PORT_UCHAR(PortAddr +2));
   bpap2 = (ControlRegGlobal | 0x04) & 0x1C;

   // Start time slot
   WRITE_PORT_UCHAR(PortAddr + 2, (UCHAR) (bpap2 | 0x02));  

   // Wait for busy to pass for overdrive parts
   KeStallExecutionProcessor(16);                             

   OverDrive = ((READ_PORT_UCHAR(PortAddr+1)^0x80)&0x90) ? TRUE : FALSE;

   // let spooler back in
   KeLowerIrql(DISPATCH_LEVEL);                                

   i = 0;
   // Wait for time slot to finish
   while (!((READ_PORT_UCHAR(PortAddr+1)^0x80)&0x90) && (i++ < MAX_WAIT_TS))
      KeStallExecutionProcessor(4);  

   // Drive ENI\ back high
   //WRITE_PORT_UCHAR(PortAddr + 2, (UCHAR) (bpap2 & 0xFD));    

   // Drive a couple to our extra cs lines low 
   WRITE_PORT_UCHAR(PortAddr, NAND_MASK);
   KeStallExecutionProcessor(2);

   WRITE_PORT_UCHAR(PortAddr + 2, (UCHAR)(ControlRegGlobal & CONTROL_REG_MASK));

   // let spooler back in
   KeLowerIrql(oldIrql);                                
   // Give 14 a little time to rise 
   KeStallExecutionProcessor(5);              

   return OverDrive;                            
}

/////////////////////////////////////////////////////////////////////////////
//
//   Check for the presence of an adapter. 
//
UCHAR docheck(PUCHAR PortAddr)
{
   UCHAR bpap2;                            
   KIRQL oldIrql; // Current irterrupt request level 
   UCHAR Busy = FALSE;
   int   i;
   UCHAR ControlRegGlobal;


   // Keep spooler from running during a time slot
   KeRaiseIrql(DISPATCH_LEVEL, &oldIrql);        

   // 
   // Added in 2.54 to ensure ENI\ is high when D/CLK\ and RES\ are 
   // set to their initial state
   //
   WRITE_PORT_UCHAR(PortAddr, 0xDF);    
   KeStallExecutionProcessor(2);   

   // Set initial state of data lines
   WRITE_PORT_UCHAR(PortAddr, 0xFF);    

   KeStallExecutionProcessor(2);                             

   // Save control register
   //bpap2 = (READ_PORT_UCHAR(PortAddr + 2) | 0x04) & 0x1C;        
   ControlRegGlobal = (READ_PORT_UCHAR(PortAddr + 2));
   bpap2 = (ControlRegGlobal | 0x04) & 0x1C;

   // Start time slot
   WRITE_PORT_UCHAR(PortAddr + 2, (UCHAR) (bpap2 | 0x02));  

   // Wait for busy
   KeStallExecutionProcessor(4);                             

   Busy = ((READ_PORT_UCHAR(PortAddr + 1) ^ 0x80) & 0x90) ? FALSE : TRUE;

   if (Busy)
   {
      i = 0;                      
      while (!((READ_PORT_UCHAR(PortAddr+1) ^ 0x80) & 0x90) && (i++ < 25))
         KeStallExecutionProcessor(4);  

      if (i > 24)
         Busy = FALSE;
   }

   // Drive ENI\ back high
   //WRITE_PORT_UCHAR(PortAddr + 2, (UCHAR) (bpap2 & 0xFD));    

   // Drive a couple to our extra cs lines low 
   WRITE_PORT_UCHAR(PortAddr, NAND_MASK);    
   KeStallExecutionProcessor(2);
   WRITE_PORT_UCHAR(PortAddr + 2, (UCHAR)(ControlRegGlobal & CONTROL_REG_MASK));

   // let spooler back in
   KeLowerIrql(oldIrql);                                
   // Give 14 a little time to rise 
   KeStallExecutionProcessor(5);              

   return Busy;                            
}

/////////////////////////////////////////////////////////////////////////////
//
//   This function manages the communication with the DS1410E(s).
//
UCHAR docomm(UCHAR com_byte, PUCHAR PortAddr)
{
   UCHAR bpap2;                            
   UCHAR BitVal;                          
   KIRQL oldIrql; // Current irterrupt request level 
   int   i;
   UCHAR ControlRegGlobal;

   // Keep spooler from running during a time slot
   KeRaiseIrql(DISPATCH_LEVEL, &oldIrql);        

   // 
   // Added in 2.54 to ensure ENI\ is high when D/CLK\ and RES\ are 
   // set to their initial state
   //
   WRITE_PORT_UCHAR(PortAddr, com_byte & 0xDF);    
   KeStallExecutionProcessor(2);   
   
   // Set initial state of data lines
   WRITE_PORT_UCHAR(PortAddr, com_byte);    

   KeStallExecutionProcessor(2);   

   // Save control register
   //bpap2 = (READ_PORT_UCHAR(PortAddr + 2) | 0x04) & 0x1C;        
   ControlRegGlobal = (READ_PORT_UCHAR(PortAddr + 2));
   bpap2 = (ControlRegGlobal | 0x04) & 0x1C;

   // Start time slot
   WRITE_PORT_UCHAR(PortAddr + 2, (UCHAR) (bpap2 | 0x02));  

   // Wait for busy
   KeStallExecutionProcessor(2);                             

   // Drive CLK\ high 
   WRITE_PORT_UCHAR(PortAddr, 0xFF);                        

   i = 0;                      
   while (!((READ_PORT_UCHAR(PortAddr + 1) ^ 0x80) & 0x90) && (i++ < MAX_WAIT))
      KeStallExecutionProcessor(1);  

   // Drive clk line low to get our bit
   WRITE_PORT_UCHAR(PortAddr, 0xFE);      
   // Wait for valid data 
   KeStallExecutionProcessor(2);                        
   BitVal = ((READ_PORT_UCHAR(PortAddr + 1) ^ 0x80) & 0x90) ? TRUE : FALSE;
   
   // Drive ENI\ back high
   //WRITE_PORT_UCHAR(PortAddr + 2, (UCHAR) (bpap2 & 0xFD));    
   

   // Drive a couple to our extra cs lines low 
   WRITE_PORT_UCHAR(PortAddr, NAND_MASK);    
   KeStallExecutionProcessor(2);
   WRITE_PORT_UCHAR(PortAddr + 2, (UCHAR)(ControlRegGlobal & CONTROL_REG_MASK));

   // let spooler back in
   KeLowerIrql(oldIrql);                                
   // Give 14 a little time to rise 
   KeStallExecutionProcessor(3);              

   return BitVal;                            
}

/////////////////////////////////////////////////////////////////////////////
//
//   This function sends an entire byte to the DS1481. It should only be
// called in overdrive mode !!! 
//
UCHAR FastByte(UCHAR SB, PUCHAR PortAddr)
{
   UCHAR bpap2;                            
   UCHAR BitVal, ByteVal;                          
   UCHAR com_byte;
   KIRQL oldIrql; // Current irterrupt request level 
   int   i, j;
   UCHAR ControlRegGlobal;


   // Keep spooler from running during a time slot
   KeRaiseIrql(DISPATCH_LEVEL, &oldIrql);        
   // Save control register
   //bpap2 = (READ_PORT_UCHAR(PortAddr + 2) | 0x04) & 0x1C;        
   ControlRegGlobal = (READ_PORT_UCHAR(PortAddr + 2));
   bpap2 = (ControlRegGlobal | 0x04) & 0x1C;

   ByteVal = 0;
   for (j = 0; j < 8; j++)
   {
      com_byte = (SB & 1) ? WRITE_1 : WRITE_0;
      SB >>= 1;

      // D0-7 = 0xFE, don't do slow out if unneccessary (for j > 0)
      if ((!j) || (com_byte == WRITE_1))
      {
         // Set initial state of data lines
         WRITE_PORT_UCHAR(PortAddr, com_byte);    
      }
   
      // Start time slot
      WRITE_PORT_UCHAR(PortAddr + 2, (UCHAR) (bpap2 | 0x02));  
   
      // Wait for busy
      KeStallExecutionProcessor(3);                             
   
      // Drive CLK\ high 
      WRITE_PORT_UCHAR(PortAddr, 0xFF);                        
   
      i = 0;                      
      while (!((READ_PORT_UCHAR(PortAddr+1)^0x80)&0x90) && (i++<MAX_WAIT))
         KeStallExecutionProcessor(1);  
   
      // Drive clk line low to get our bit
      WRITE_PORT_UCHAR(PortAddr, 0xFE);      
      BitVal = ((READ_PORT_UCHAR(PortAddr + 1) ^ 0x80) & 0x90) ? TRUE : FALSE;
      
      // Drive ENI\ back high
      WRITE_PORT_UCHAR(PortAddr + 2, (UCHAR) (bpap2 & 0xFD));    
      KeStallExecutionProcessor(1);

      ByteVal >>= 1;
      if (BitVal)
         ByteVal |= 0x80;
   }

   // All data lines should be left high
   //   WRITE_PORT_UCHAR(PortAddr, 0xFF);
   WRITE_PORT_UCHAR(PortAddr, NAND_MASK);
   KeStallExecutionProcessor(2);
   WRITE_PORT_UCHAR(PortAddr + 2, (UCHAR)(ControlRegGlobal & CONTROL_REG_MASK));

   // Let spooler back in
   KeLowerIrql(oldIrql);

   return ByteVal;
}




