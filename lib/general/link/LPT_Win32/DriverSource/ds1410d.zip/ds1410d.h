//////////////////////////////////////////////////////////////////////////////
//
// ds1410d.h                              
//
//////////////////////////////////////////////////////////////////////////////

//#define DO_DEBUG              // uncomment if you want to print debug messages with DebugPrint calls
#ifdef DO_DEBUG
   #include "DebugPrint.h"
#endif

#include "parallel.h"

#define MAX_PAR_NUM      8      // Number of parallel ports we support (is changeable)

#define DO_RESET         0x00   // Reset command byte
#define DO_BIT           0x01   // Bit command byte
#define DO_BYTE          0x02   // Byte command byte
#define TOGGLE_OVERDRIVE 0x03   // Send toggle overdrive sequence
#define TOGGLE_PASSTHRU  0x04   // Send toggle passthru sequence
#define CHECK_BRICK      0x05   // Check for presence of an adapter
#define SET_PORT         0x06   // Set parallel port number 
#define DO_BLOCK         0x20   // Block I/O 
#define FAST_ACCESS      0x21   // Fast weak access
#define CHECK_OVERDRIVE  0x22   // Overdrive detection (w/o state change)

#define DOW_RESET  0xFD
#define WRITE_1    0xFF
#define WRITE_0    0xFE
#define READ_1     0xFF
#define READ_0     0xFF

#define DOW_ACCESS 0x55

#define MAX_BLOCK   128  
#define MAX_WAIT    4000 
#define MAX_WAIT_TS 25 

typedef struct _DOW_DEVICE_EXTENSION  
{
   PDEVICE_OBJECT  DeviceObject;            // Back pointer to Device Object
   PUCHAR          Controller[MAX_PAR_NUM]; // Mapped addresses 
   ULONG           SpanOfController;        // Always 3 for us
   BOOLEAN         UnMapRegisters;
   ULONG           CRLen;                   // Byte length of comm 
   UCHAR           CommResult[MAX_BLOCK];     
   USHORT          PDEBpa;                  // Base port address
   UCHAR           pn;                      // Current port number (0 based) 
   UCHAR           ParNumFound;             // Ports found at init time 
   BOOLEAN         GoodPort;
   INTERFACE_TYPE  InterfaceType;
   ULONG	       BusNumber;
   ULONG		   Vector;     
   KINTERRUPT_MODE InterruptMode;
   KAFFINITY	   Affinity;
   ULONG           PortAddress;   
   ULONG           ReservedStuff;           // For whatever pops up
}
DOW_DEVICE_EXTENSION, *PDOW_DEVICE_EXTENSION;

                                    
NTSTATUS DS1410XDispatch(IN PDEVICE_OBJECT ODevObject, IN PIRP OIrp);

NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject,
                     IN PUNICODE_STRING RegistryPath);

VOID DOWDriverUnload(IN PDRIVER_OBJECT DOWDriverObject);

VOID DOWCleanUpDevice(IN PDEVICE_OBJECT DOWDeviceObject, IN UCHAR);

PVOID DOWGetMmAddress(IN INTERFACE_TYPE BusType,
                      IN ULONG BusNumber,
                      PHYSICAL_ADDRESS IoAddress,
                      ULONG NumberOfBytes,
                      ULONG AddressSpace,
                      PBOOLEAN UMap);

UCHAR docomm(UCHAR, PUCHAR);                   
UCHAR dotoggle(PUCHAR);
UCHAR docheck(PUCHAR);
UCHAR CheckOD(PUCHAR);
UCHAR FastByte(UCHAR, PUCHAR);