/* dow95.h */

//
//  Copyright (C) 1995 Dallas Semiconductor Corporation.
//  All rights Reserved. Printed in U.S.A.
//  This software is protected by copyright laws of
//  the United States and of foreign countries.
//  This material may also be protected by patent laws of the United States
//  and of foreign countries.
//  This software is furnished under a license agreement and/or a
//  nondisclosure agreement and may only be used or copied in accordance
//  with the terms of those agreements.
//  The mere transfer of this software does not imply any licenses
//  of trade secrets, proprietary technology, copyrights, patents,
//  trademarks, maskwork rights, or any other form of intellectual
//  property whatsoever. Dallas Semiconductor retains all ownership rights.
//

/*
 $Workfile: Dow95.h $
 $Revision: 2 $
 $Date: 12/21/98 1:01p $
 $Author: Tomc $
 $Modtime: 12/21/98 1:00p $
 $Log: /DOS Button/VSAuthD/Dow95.h $
* 
* 2     12/21/98 1:01p Tomc
*/


#ifndef _DOW95_H_
#define _DOW95_H_

typedef unsigned char  uchar;
typedef unsigned short ushort;
typedef unsigned int   uint;
typedef unsigned long  ulong;

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#ifdef __cplusplus
extern "C" {
#endif

uchar  OverdriveOn     (void);
void   OverdriveOff    (void);
uchar  ToggleOverdrive (void);
uchar  setup           (uchar);
uchar  dowcheck        (void);
uchar  keyopen         (void);
uchar  keyclose        (void);
uchar  first           (void);
uchar  next            (void);
uchar  gndtest         (void);
uchar  *romdata        (void);
uchar  databyte        (uchar);                                           
uchar  access          (void);
uchar  garbagebag      (uchar *);// returns lastone for SACWD300.dll

#ifdef __cplusplus
}
#endif

#endif /* _DOW95_H_ */

/* dow95.h */