//  Software Authorization, Access System for Windows 95
//  Driver is dynamically loadable - The driver needs to
//  be physically located in the %WINDOWS%\system directory.
//  07/25/95 (TAC)
//
//  Copyright (C) 1995 Dallas Semiconductor Corporation.
//  All rights Reserved. Printed in U.S.A.
//  This software is protected by copyright laws of
//  the United States and of foreign countries.
//  This material may also be protected by patent laws of the United States
//  and of foreign countries.
//  This software is furnished under a license agreement and/or a
//  nondisclosure agreement and may only be used or copied in accordance
//  with the terms of those agreements.
//  The mere transfer of this software does not imply any licenses
//  of trade secrets, proprietary technology, copyrights, patents,
//  trademarks, maskwork rights, or any other form of intellectual
//  property whatsoever. Dallas Semiconductor retains all ownership rights.
//
//  12-05-96 (TAC) - Added DO_BLOCK, FAST_ACCESS and CHECK_OVERDRIVE functions.
//

/*
 $Workfile: VSAuthD.c $
 $Revision: 20 $
 $Date: 6/16/02 4:33p $
 $Author: Shughes $
 $Modtime: 6/16/02 4:32p $
 $Log: /Drivers/VSAuthD/VSAuthD.c $
 * 
 * 20    6/16/02 4:33p Shughes
 * 
 * 19    4/30/02 4:33p Shughes
 *
 * 18    3/06/02 7:50a Chenot
 * added check for divide by zero in timing calibration routine
 *
 * 17    6/04/01 11:42a Chenot
 *
 * 16    6/04/01 11:18a Chenot
 *
 * 15    6/04/01 8:14a Chenot
 *
 * 14    5/22/01 11:13a Chenot
 *
 * 13    5/22/01 8:26a Chenot
 *
 * 12    5/21/01 10:57a Chenot
 *
 * 11    5/21/01 10:30a Chenot
 *
 * 10    5/21/01 10:27a Chenot
 *
 * 9     5/21/01 10:17a Chenot
 *
 * 8     12/02/99 6:18a Tomc
 *
 * 7     12/02/99 5:45a Tomc
 *
 * 6     10/13/99 11:40a Tomc
 *
 * 5     10/12/99 2:20p Tomc
 *
 * 4     10/12/99 12:54p Tomc
 *
 * 3     10/12/99 12:36p Tomc
 * Added code to preserve control register (bpa+2)
 *
 * 2     2/04/99 10:45a Tomc
*/

#define WANTVXDWRAPS

#include <stdlib.h>
#include <basedef.h>
#include <vmm.h>
#include <vwin32.h>
#include <winerror.h>
#include "vsauthd.h"

#pragma data_seg( "_DATA", "CODE" )

////////////////////////////////////////////////////////////////////////////////
/*void beep(void)
{
  _asm
  {
    push     ax                       ; Preserve callers registers.
    push     bx
    push     cx
    push     dx
    mov      al,         0B6H         ; Write timer mode register.
    out      43H,        al           ; Send it to timer.
    mov      dx,         14H          ; Timer divisor =
    mov      ax,         4F38H        ;    1331000 / frequency.
    mov      cx,         3000         ; Get frequency in cx.
    div      cx                       ; Do the division.
    out      42H,        al           ; Write low byte timer 2 count.
    mov      al,         ah           ; Get high byte in al.
    out      42H,        al           ; Write high byte timer 2 count.
    in       al,         61H          ; Get current port B setting.
    mov      ah,         al           ; Save port B setting.
    or       al,         3            ; Prepare to turn speaker on.
    out      61H,        al           ; Turn speaker on.
    mov      cx,       6000           ; Counts to burn usecs.
    shl      cx,         10           ; Multilpy by 1024.

    here:
    loop     here                     ; wait count.
    mov      al,         ah           ; Get port value.
    out      61H,        al           ; Restore port value.
    pop      dx                       ; Restore callers registers.
    pop      cx
    pop      bx
    pop      ax
  }
}*/

/*
static char msgBuf[255];

static void alert(char* msg)
{
   WORD resp = 0;
   VSEB vseb;
   vseb.vseb_resp = (DWORD)&resp;
   vseb.vseb_b3 = 0x8008; //Default + Close
   vseb.vseb_b2 = 2; //Okay
   vseb.vseb_b1 = 1; //Yes
   vseb.vseb_pszCaption = (DWORD)msg;
   vseb.vseb_pszText = (DWORD)"Alert Alert Alert Alert";

   _asm
   {
      push EBX
      mov EBX, DWORD PTR vseb
      VMMCall(VWIN32_SysErrorBox);
      pop EBX
   }
}
*/

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
#pragma VxD_LOCKED_CODE_SEG
#pragma VxD_LOCKED_DATA_SEG
////////////////////////////////////////////////////////////////////////////////
void outcall(ushort port,uchar data) // send data to port
{
  _asm
  {
    mov dx,port
    mov al,data
    out dx,al
  }
}
////////////////////////////////////////////////////////////////////////////////
uchar incall(ushort port) // return data read from port
{
  uchar data;
  _asm
  {
    mov dx,port
    in al,dx
    mov data,al
  }

  return data;
}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//      This procedure burns cycles. It waits until the 8253 has counted down
//   wait_count counts. (Xtal = 2.3686 MHz (or something around there)).
//                            = 1.193180MHz according to several sources
//-> tick every .422 usecs --- 60 usecs wait_count ~= 143 (theoretically)
//-> seems to require twice as many (empirically)
////////////////////////////////////////////////////////////////////////////////
// timing will become invalid if turbo button is pressed
////////////////////////////////////////////////////////////////////////////////
static void wait_counts(ushort CountVal)    /* Waits for 4-6 usec */
{
  _asm
  {
    xor ecx, ecx          // added 11/13/95
    mov cx,  CountVal
  }
X:
  _asm
  {
    loop X
  }
}
////////////////////////////////////////////////////////////////////////////////
// timing will become invalid if turbo button is pressed
////////////////////////////////////////////////////////////////////////////////
static ushort CountVal = 0;
static ushort usCount = 0;
static ushort timesToLoop = 1;
static void Wait_us()    /* Waits for 1 usec */
{
   int loopCnt = timesToLoop;
   
waitloop: /* outer loop jump label */
  _asm
  {
    /* inner loop */
    movzx  ecx, usCount
    loop   $
    /* */
    
    /* outer loop */
    dec    loopCnt
    jnz    waitloop
    /* */
  }

}
////////////////////////////////////////////////////////////////////////////
static void Timit(void)
{
  _asm
  {
    mov     al, 0           /* Load the freeze command. */
    out     43H, al         /* Freeze the initial count.*/
    in      al, 40H         /* Get LS byte of count.    */
    mov     bl, al          /* Save LS count byte.      */
    in      al, 40H         /* Get MS byte of count.    */
    mov     bh, al          /* Initial count now in BX. */
  }
L:
  _asm
  {
    loop    L               /* Count up to CX.            */
    mov     al, 0           /* Load the freeze command.   */
    out     43H, al         /* Freeze the final count.    */
    in      al, 40H         /* Get LS byte of count.      */
    mov     ah, al          /* Save LS count byte.        */
    in      al, 40H         /* Get MS byte of count.      */
    xchg    al, ah          /* Final count now in AX.     */
    xchg    ax, bx          /* Position data to subtract. */
    sub     ax, bx          /* Count difference now in AX.*/
  }
}
////////////////////////////////////////////////////////////////////////////
static void GetTiming(ushort *CountVal, ushort *timesToLoop)
{
  /* 
   * update 1.00B - Function now gets the CountVal, which lets the Wait_us
   * now how many cycles to burn for a single microsecond.  Since this
   * number was overflowing on faster machines, there is now a second
   * loop counter (an outer counter) which tells Wait_us how many times
   * it should burn it's specified number of cycles
   */
  ushort numLoop = 1;
  ushort loopCount = 2048;
  ushort quotient;
  ushort tmp_count = 0;
  
  _asm
  {
    push    ax
    push    bx
    push    ecx
    push    dx
    xor     ecx, ecx        // added 07/20/98 and pushed ecx instead of cx

    pushf                   /* Save the state of interrupts.  */
    cli                     /* Disable interrupts.            */
    mov     cx, 1           /* Prepare to measure offset.     */
    call    Timit           /* Measure constant offset.       */
    push    ax              /* Save constant on stack.        */
  }
  
loopcount:
  _asm
  {
    mov     cx, loopCount   /* Get the loop count value.      */
    inc     cx              /* add offset for constant value. */
    call    Timit           /* Measure the total time.        */
    
    pop     bx              /* Retrieve the constant part.    */
    mov     cx, bx
    sub     ax, bx          /* AX = Time for 2048<<loopCount loops. */
    
    cmp     ax, 4           /* make sure ax is greater than 4  v1.00b */
    ja      division        /* if so, division is safe         v1.00b */
    
    push    cx              /* push the constant part back on the stack  v1.00b */
    inc     numLoop         /* we need to have more loops to take care of this delay.  v1.00b */
    shl     loopCount, 1    /* double the loop count value for timit.  v1.00b */
    jnz     loopcount       /* if it's zero, we've overflowed.  v1.00b */
    
    pop     cx              /* pop constant part off the stack  v1.00b */
    jmp     overflow        /* handle overflow                  v1.00b */
  }

division:
  _asm
  {
    jz      zerodivisor     /* Check for zero divisor         */
    mov     bx, ax          /* Get divisor in bx.             */
/*
 *  Windows 3.0 and 3.1 seem to use a clock tic that
 *  is twice as fast as what is available in DOS. V1.004
 *  Windows 95 counts are 3/2 the expected period. (i.e. 4 us is really 6 us)
*/
    mov     dx, 2           /* Dividend DX:AX = 156392        V1.004 */
    mov     ax, 062E8h      /*    = 2.38636 * 64 * 2048 / 2   V1.004 */
    div     bx              /* Quotient in AX, rem in DX.            */
    
    inc     ax              /* Round up to nearest integer.          */
    shr     ax, 4           /* Get count for 4 usec. 64 default      */
    mov     tmp_count, ax   /* Store result in Count.                */
    mov     quotient, bx    /* save quotient                         */
    
    jmp     zerodivisor
  }

overflow:
  _asm
  {
    mov tmp_count, 0FFFFh   /* assume maximum amount in overflow case v1.00b */
  }

zerodivisor:
  _asm
  {
    pop     cx              /* replace popf with pop cx, testz v1.003 */
    test    ch,  2
    jz      norestore       /* jmp to no-restore                     */
    sti
  }

norestore:
   _asm
  {
    pop     dx
    pop     ecx
    pop     bx
    pop     ax
  }
  
  *CountVal = tmp_count;
  *timesToLoop = numLoop;
}
////////////////////////////////////////////////////////////////////////////
ushort GetCalibration()
{
  int i = 0;
  int max = 0;
  int numLoops = 0;

  // v1.00a, take max of 10 tries
  for(i = 0; i < 10; i++)
  {
    GetTiming(&CountVal, &timesToLoop);

    if(CountVal > max)
    {
      max = CountVal;
      numLoops = timesToLoop;
    }
  }

  CountVal = max;
  timesToLoop = numLoops;
  
  usCount = CountVal / 6;  // setup microsecond counter

  if(!usCount)
    usCount = 1;

  return CountVal;
}
////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
//
static uchar  IsECPMode378     = 0xff;
static uchar  IsECPMode278     = 0xff;
static uchar  IsECPMode3BC     = 0xff;
// handle the big 3 port addresses for now
#define IS_ECP_MODE (bpa==0x378)? (IsECPMode378==1): \
                    (bpa==0x278)? (IsECPMode278==1): \
                    (bpa==0x3BC)? (IsECPMode3BC==1): FALSE
//
////////////////////////////////////////////////////////////////////////////
BOOL TestECPPort(ushort bpa)
{
  uchar ExtendedControlReg        = inb((ushort)(bpa + ECPPORT_ECR_OFFSET));
  uchar ControlReg                = inb((ushort)(bpa + 2));
  uchar ExtendedControlRegGlobal  = ExtendedControlReg;
  uchar ControlRegGlobal          = ControlReg;
//int i,j;
  // test for ECR.0 (FIFO Empty) == 1 and ECR.1 (FIFO Full) == 0
  if((ExtendedControlReg & 0x03) != 1)
    return FALSE;

  // test for CR.1 == ECR.1
  if((ControlReg & 0x02) == 0)
  {
    // force CR.1 to 1
    // XOR with 0x02 to flip bit 1
    outb((ushort)(bpa + 2), (uchar)(ControlReg ^ 2));
    ExtendedControlReg  = inb((ushort)(bpa + ECPPORT_ECR_OFFSET));
    ControlReg          = inb((ushort)(bpa + 2));
  }

  // verify the values are different
  // if they are not the port probably doesn't
  // decode at least 11 bits of the address and
  // BPA+402h is the same as BPA+2 as far as the
  // port decode logic is concerned

  if((ExtendedControlReg & 0x02)==(ControlReg & 0x02))
  {
    outb((ushort)(bpa + 2), ControlRegGlobal);
    return FALSE;
  }

  // verify lower bits are read-only
  outb((ushort) (bpa + ECPPORT_ECR_OFFSET), 0x34);

  // verify lower bits are read-only
  if((inb((ushort) (bpa + ECPPORT_ECR_OFFSET))) == 0x35)
  {
    // restore original state
    outb((ushort)(bpa + ECPPORT_ECR_OFFSET), ExtendedControlRegGlobal);
    outb((ushort)(bpa + 2), ControlRegGlobal);
/*
// debug - seize the pc for 5 seconds if we get here
 for(i=0;i<5;i++)
 for(j=0;j<1000000;j++)
 Wait_us();
*/
    return TRUE;
  }

  // restore original state
  outb((ushort)(bpa + ECPPORT_ECR_OFFSET), ExtendedControlRegGlobal);
  outb((ushort)(bpa + 2), ControlRegGlobal);
  return FALSE;
}
//////////////////////////////////////////////////////////
/////////////// software auth vars ///////////////////////

#define MAXTIMECOUNT 5
// default address,
// actual address is passed in with driver calls
static ushort bpa              = 0x378;
static ushort TimeCounter      = 0;
static BOOL   ResetTimeCounter = TRUE;

//////////////////////////////////////////////////////////
//////////////////// VxD vars ////////////////////////////

HVM hSysVM;
DWORD _stdcall CVXD_W32_DeviceIOControl(DWORD, DWORD, DWORD, LPDIOC);
DWORD _stdcall CVXD_CleanUp(void);

//////////////////////////////////////////////////////////
/* from vwin32.h
/*
// these structures are in vmm.inc
//
Client_Reg_Struc	STRUC
Client_Word_Reg_Struc	STRUC
Client_Byte_Reg_Struc	STRUC

typedef struct DIOCParams
{
	DWORD	Internal1;		// ptr to client regs
	DWORD	VMHandle;		// VM handle
	DWORD	Internal2;		// DDB
	DWORD	dwIoControlCode;
	DWORD	lpvInBuffer;
          bytes:
            0..7 always rom id
	DWORD	cbInBuffer;
	DWORD	lpvOutBuffer;
	DWORD	cbOutBuffer;
          bytes:
            0..7 always rom id
	DWORD	lpcbBytesReturned;
	DWORD	lpoOverlapped;
	DWORD	hDevice;
	DWORD	tagProcess;
} DIOCPARAMETERS;
*/
////////////////////////////////////////////////////////////////////////////////
//                  CVXD_W32_DeviceIOControl
////////////////////////////////////////////////////////////////////////////////
#define DRIVER_VERSION 0x0001000d // (WORD)Major:(WORD)Minor
DWORD _stdcall VSAuthD_W32_DeviceIOControl(DWORD  dwService,
                                           DWORD  dwDDB,
                                           DWORD  hDevice,
                                           LPDIOC lpDIOCParms)
{
  int     i,j;
  DWORD   dwRetVal = 0,
          Handle;
  uchar   SA_Parm;
  uchar   *pRetVal   = (uchar *)lpDIOCParms->lpvInBuffer;
  uchar   *pBlockLen = (uchar *)(lpDIOCParms->lpvInBuffer +
                                 sizeof(SA_Parm) +
                                 sizeof(bpa));
  uchar   *BlockBuff = pBlockLen + 1;
  ushort  *pBPA      = (ushort *)&pRetVal[1];
  ushort  junkCount = 0;
  uchar   junk;
  uchar   ExtendedControlReg,
          ExtendedControlRegGlobal;

  SA_Parm = *(pRetVal);
  bpa     = *pBPA;

  i = 0;


  if(!CountVal)
  {
    GetCalibration();
  }

  // check for ECP port
  switch(bpa)
  {
    case 0x378:
      if(IsECPMode378 == 0x0ff)
        TestECPPort(bpa)? (IsECPMode378 = 1): (IsECPMode378 = 0);
    break;

    case 0x278:
      if(IsECPMode278 == 0x0ff)
        TestECPPort(bpa)? (IsECPMode278 = 1): (IsECPMode278 = 0);
    break;

    case 0x3BC:
      if(IsECPMode3BC == 0x0ff)
        TestECPPort(bpa)? (IsECPMode3BC = 1): (IsECPMode3BC = 0);
    break;
  }

  if((dwService >= DOWRESET) && IS_ECP_MODE)
  {
    // Get the ECP ECR info
    ExtendedControlRegGlobal = inb((ushort) (bpa + ECPPORT_ECR_OFFSET));
    // This will set the port to SPP mode
    ExtendedControlReg = ExtendedControlRegGlobal & SPPMODE_AND_MASK;
    outb((ushort)(bpa + ECPPORT_ECR_OFFSET), (uchar)(ExtendedControlReg));
  }

  switch (dwService)
  {
    case DIOC_OPEN:// 0 in vmm.h
      // Must return 0 to tell WIN32 that this VxD supports DEVIOCTL
      dwRetVal = 0;
    break;

    case DIOC_CLOSEHANDLE:// -1 in vmm.h
      // Dispatch to cleanup proc
      dwRetVal = VXD_SUCCESS;
    break;

    case GET_DRIVER_VERSION:
      *((DWORD *)BlockBuff) = DRIVER_VERSION;

      dwRetVal = 0;
    break;

    case DOWBIT:
      dwRetVal = (DWORD)(*pRetVal = SA_DOWBit(SA_Parm));
    break;

    case DOWBYTE:
      dwRetVal = (DWORD)(*pRetVal = SA_DOWByte(SA_Parm));
    break;

    case DOWRESET:
      dwRetVal = (DWORD)(*pRetVal = SA_DOWReset());
    break;

    case DOWTOGGLEOD:
      dwRetVal = (DWORD)(*pRetVal = SA_DOWToggleOverDrive());
    break;

    case DOWTOGGLEPASS:
      for(i = 0; i < 4; i++)
      {
        SA_DOWToggleOverDrive();
        for(j = 0; j < 4; j++,Wait_us());
      }

      dwRetVal = (DWORD)(*pRetVal = TRUE);
    break;

    case DOWCHECKBSY:
      dwRetVal = (DWORD)(*pRetVal = SA_DOWCheckBusy());
    break;

    case DO_BLOCK:
      if((!BlockBuff) || (!(*pBlockLen)))
        dwRetVal = (DWORD)(*pRetVal = FALSE);
      else
      {
        for(i=0; i<*pBlockLen; i++)    // for now use the same buffer for input
          BlockBuff[i] = SA_DOWFastByte(BlockBuff[i]); // data and output data

        dwRetVal = (DWORD)(*pRetVal = TRUE);
      }
    break;

    case FAST_ACCESS:
      if((!BlockBuff) || (*pBlockLen != 8))
        dwRetVal = (DWORD)(*pRetVal = FALSE);
      else
        dwRetVal = (DWORD)(*pRetVal = SA_DOWFastAccess(BlockBuff));
    break;

    case CHECK_OVERDRIVE:
      dwRetVal = (DWORD)(*pRetVal = SA_DOWCheckOverdrive());
    break;

    case 0x55:// for debugging - crank out square waves on all data lines
              //               - timing
      outb(bpa, 0xFF);
      outb(bpa, 0x00);
      wait_counts(CountVal);
      outb(bpa, 0xFF);
      wait_counts(CountVal);
      outb(bpa, 0x00);
      wait_counts(CountVal);
      outb(bpa, 0xFF);
      dwRetVal = 0;
    break;

    case 0x56:// for debugging - crank out a square wave on pin 17
              //               - scope trigger
      junk = inb((ushort)(bpa + 2));
      outb((ushort)(bpa + 2), (uchar)(junk | 0x08));
      wait_counts(CountVal);
      outb((ushort)(bpa + 2), (uchar)(junk & 0xf7));
      wait_counts(CountVal);
      outb((ushort)(bpa + 2), junk);
      dwRetVal = 0;
    break;

    case 0x57:// v1.007, get calibration value
      junkCount = CountVal;

      for(i = 0; i < sizeof(junkCount); i++)
        BlockBuff[i] = ((junkCount >> (8*i)) & 0x0ff);

      dwRetVal = 0;
    break;

    case 0x58:// v1.00a, set calibration value
      junkCount = GetCalibration();

      for(i = 0; i < sizeof(junkCount); i++)
        BlockBuff[i] = ((junkCount >> (8*i)) & 0x0ff);

      dwRetVal = 0;
    break;

    default:
        // Returning a positive value will cause the WIN32 DeviceIOControl
        // call to return FALSE, the error code can then be retrieved
        // via the WIN32 GetLastError
      dwRetVal = ERROR_NOT_SUPPORTED;
    break;
  }// switch

  if((dwService >= DOWRESET) && IS_ECP_MODE)
  {
    // Turn port back into an ECP
    outb((ushort)(bpa + ECPPORT_ECR_OFFSET), (uchar)(ExtendedControlRegGlobal));
  }

  return(dwRetVal);
}
////////////////////////////////////////////////////////////////////////////////
DWORD _stdcall CVXD_CleanUp(void)
{
  return(VXD_SUCCESS);
}
////////////////////////////////////////////////////////////////////////////////
//                 VSAUTHD_VMAPI (16 bit DOS Mode)
//
//     ENTRY: function - the function number (passed in eax)
//         parm1 - parameter 1 (passed in ebx)
//         parm2 - parameter 2 (passed in ecx)
//
//     EXIT:    NONE
////////////////////////////////////////////////////////////////////////////////
// not used now
int _stdcall VSAUTHD_VMAPI(unsigned int function,
                        unsigned int parm1,
                        unsigned int parm2)
{
  int retcode = 1;
  return (retcode);
}
////////////////////////////////////////////////////////////////////////////////
//                 VSAUTHD_PMAPI (16 bit Protected Mode)
//
//     ENTRY: function - the function number (passed in eax)
//         parm1 - parameter 1 (passed in ebx)
//         parm2 - parameter 2 (passed in ecx)
//
//     EXIT:    NONE
////////////////////////////////////////////////////////////////////////////////
// not used now
int _stdcall VSAUTHD_PMAPI(unsigned int function,
                        unsigned int parm1,
                        unsigned int parm2)
{
  int retcode = 1;
  return (retcode);
}
////////////////////////////////////////////////////////////////////////////////
DWORD _stdcall VSAuthD_Dynamic_Exit(void)
{
    return(VXD_SUCCESS);
}
/////////////////////////// DOW Functions //////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
static uchar SA_DOWCheckBusy()
{
  int   i;
  uchar DOWRes,
        ControlReg,
        ControlRegGlobal,
        Busy = FALSE;

  // send reset for last part detection
  SA_DOWReset();

  // disable interrupts
  _asm cli;

  // Don't clock all the data lines in case eni/ is grounded
  outb(bpa, 0xDF);

  // Spin
  for(i=0;i<2;i++,Wait_us());

  // Set initial state of data lines
  outb(bpa, 0xFF);

  // Spin
  for(i=0;i<2;i++,Wait_us());

  // Save I/O pins and force 16 high
  ControlRegGlobal = inb((ushort)(bpa + 2));
  ControlReg =  ControlRegGlobal | 0x04;

  // Mask EPP bits
  ControlReg &= 0x1C;

  // Drive 14 (chip select) low
  outb((ushort)(bpa + 2), (uchar)(ControlReg | 0x02));

  // Spin
  for(i=0;i<8;i++,Wait_us());

  // Wait for DS1481 to issue busy signal
  for(i=0;i<8;i++)
    if((Busy = ((inb((ushort)(bpa + 1)) ^ 0x80) & 0x90)?FALSE:TRUE))
      break;
    else
      wait_counts(CountVal);//wait 4us or so

  // reset TimeOut
  TimeOut(0);

  if(Busy)
    while(!((inb((ushort)(bpa + 1)) ^ 0x80) & 0x90)&&(Busy=(TimeOut(20)?FALSE:TRUE)));

  // Drive pin 14 (ENI\) back high again !!!
  //outb((ushort)(bpa + 2), (uchar)(ControlReg & 0xFD));

  // Drop a couple lines low to disable nand gate
  outb((ushort)bpa, NAND_MASK);

  // Spin
  for(i=0;i<2;i++,Wait_us());

  outb((ushort)(bpa + 2), (uchar)(ControlRegGlobal&CONTROL_REG_MASK));

  // Allow interrupts back in
  _asm sti

  // Spin
  for(i=0;i<5;i++,Wait_us());

  return Busy ? TRUE : FALSE;
}
////////////////////////////////////////////////////////////////////////////////
static uchar SA_DOWCheckOverdrive(void)
{
  uchar   OverDrive = FALSE,
          Busy      = FALSE,
          ControlRegGlobal,
          ControlReg;
  ushort  i;

  // Disable interrupts
  _asm cli;

  // Don't clock all the data lines in case eni/ is grounded
  outb(bpa, 0xDF);

  // Spin
  for(i=0;i<2;i++,Wait_us());

  // Set initial state of data lines to FF
  outb((ushort)bpa, 0xFF);

  // wait a couple of usecs
  Wait_us();
  Wait_us();

  // Save I/O pins and force 16 high
  ControlRegGlobal = inb((ushort)(bpa + 2));
  ControlReg =  ControlRegGlobal | 0x04;

  // Mask EPP bits
  ControlReg &= 0x1C;

  i = 0;
  // Drive 14 (chip select) low - start time slot
  outb((ushort)(bpa + 2), (uchar)(ControlReg | 0x02));

  // wait for a period longer than an overdrive busy signal but
  // shorter than a normal busy signal.
  for(; (i<16); i++, Wait_us());

  OverDrive = ((inb((ushort)(bpa + 1)) ^ 0x80) & 0x90) ? TRUE : FALSE;

  // Allow interrupts back in
  _asm sti

  TimeOut(0);//ResetTimeCounter = TRUE;
  // Wait for time slot to finish
  while(!((inb((ushort)(bpa + 1)) ^ 0x80) & 0x90)&&(!TimeOut(17)));

  // Drive pin 14 (ENI\) high again !!!
  //outb((ushort)(bpa + 2), (uchar)(ControlReg & 0xFD));

  // Drop a couple lines low to disable nand gate
  outb((ushort)bpa, NAND_MASK);

  // Spin
  for(i=0;i<2;i++,Wait_us());

  outb((ushort)(bpa + 2), (uchar)(ControlRegGlobal&CONTROL_REG_MASK));

  // Let pin 14 come back up
  for(i=0; i<5; i++,Wait_us());

  return OverDrive;
}
////////////////////////////////////////////////////////////////////////////////
static uchar SA_DOWToggleOverDrive(void)
{
  uchar   DOWRes,
          ControlRegGlobal,
          ControlReg;
  ushort  i;

  // Disable interrupts
  _asm cli;

  // Don't clock all the data lines in case eni/ is grounded
  outb(bpa, 0xDC);

  // Spin
  for(i=0;i<2;i++,Wait_us());

  // Set initial state of data lines to FC (D0, D1 low).
  outb((ushort)bpa, 0xFC);

  // Save I/O pins and force 16 high
  ControlRegGlobal = inb((ushort)(bpa + 2));
  ControlReg = ControlRegGlobal | 0x04;

  // Mask EPP bits
  ControlReg &= 0x1C;

  // Drive 14 (chip select) low
  outb((ushort)(bpa + 2), (uchar)(ControlReg | 0x02));

  // Spin
  for(i=0;i<4;i++,Wait_us());

  // Get bit result
  DOWRes = ((inb((ushort)(bpa + 1)) ^ 0x80) & 0x90) ? TRUE : FALSE;

  // Spin
  for(i=0;i<8;i++,Wait_us());

  // Drive pin 14 (ENI\) back high again !!!
  //outb((ushort)(bpa + 2), (uchar)(ControlReg & 0xFD));

  // Drop a couple lines low to disable nand gate
  outb((ushort)bpa, NAND_MASK);

  // Spin
  for(i=0;i<2;i++,Wait_us());

  outb((ushort)(bpa + 2), (uchar)(ControlRegGlobal&CONTROL_REG_MASK));

  // Allow interrupts back in
  _asm sti;

  // Spin
  for(i=0; i<5; i++,Wait_us());

  return DOWRes;
}
////////////////////////////////////////////////////////////////////////////////
static uchar SA_DOWFastAccess(uchar *RomId)
{
  int i;

  if(!DS1481Comm(RESET))
  {
    SA_DOWFastByte(DOW_ACCESS);

    for(i=0; i<8; i++)
      SA_DOWFastByte(RomId[i]);
  }
  else
    return FALSE;

  return TRUE;
}
////////////////////////////////////////////////////////////////////////////////
static uchar SA_DOWFastByte(uchar DataByte)
{
   int    i,
          bitpos;
   uchar  ByteVal = 0,
          BitVal,
          ComByte,
          ControlRegGlobal,
          ControlReg;

  // Disable interrupts
  _asm cli;

  // Save I/O pins and force 16 high
  ControlRegGlobal = inb((ushort)(bpa + 2));
  ControlReg =  (ControlRegGlobal | 0x04) & 0x1C;

  for(bitpos = 0; bitpos < 8; bitpos++)
  {
    ComByte = (DataByte & 1) ? RWBIT : W0BIT;
    DataByte >>= 1;

    // save time on unnecessary outs
    if((!bitpos) || (ComByte == RWBIT))
    {
      // Set state of data lines
      outb(bpa, ComByte);
    }

    // Start time slot
    outb((ushort)(bpa + 2), (uchar)(ControlReg | 0x02));

    // Wait for busy
    for(i = 0; i < 3; i++,Wait_us());

    // Drive CLK\ high
    outb(bpa, 0xFF);

    i=0;

    // Wait for busy signal to go away
    while (!((inb((ushort)(bpa + 1)) ^ 0x80) & 0x90) && (i++ < MAX_WAIT))
      Wait_us();


    // Drive clk line low to get our bit
    outb(bpa, 0xFE);

    // Get bit result
    BitVal = ((inb((ushort)(bpa + 1)) ^ 0x80) & 0x90) ? TRUE : FALSE;

    // Drive pin 14 (ENI\) back high
    outb((ushort)(bpa + 2), (uchar)(ControlReg & 0xFD));

    Wait_us();

    for(i = 0; i < 10; i++,Wait_us());
      ByteVal >>= 1;

    if(BitVal)
      ByteVal |= 0x80;
  }

  // Drop a couple lines low to disable nand gate
  outb((ushort)bpa, NAND_MASK);

  // Spin
  for(i=0;i<2;i++,Wait_us());

  outb((ushort)(bpa + 2), (uchar)(ControlRegGlobal&CONTROL_REG_MASK));

  // Allow interrupts back in
  _asm sti

  Wait_us();
  Wait_us();

  // Return Byte
  return ByteVal;
}
////////////////////////////////////////////////////////////////////////////////
static uchar DS1481Comm(uchar DRegByte)
{
  uchar i,
        DOWRes,
        ControlRegGlobal,
        ControlReg;

  // Disable interrupts
  _asm cli;

  // Don't clock all the data lines in case eni/ is grounded
  outb(bpa, (uchar)(DRegByte&0xDF));

  // Spin
  for(i=0;i<2;i++,Wait_us());

  // Set initial state of data lines
  outb(bpa, DRegByte);

  // Save I/O pins and force 16 high
  ControlRegGlobal = inb((ushort)(bpa + 2));
  ControlReg =  ControlRegGlobal | 0x04;

  // Mask EPP bits
  ControlReg &= 0x1C;

  // Drive 14 (chip select) low
  outb((ushort)(bpa + 2), (uchar)(ControlReg | 0x02));

  // Allow interrupts back in
  _asm sti

  TimeOut(0);//ResetTimeCounter = TRUE;
  // Wait for DS1481 to issue busy signal
  while (((inb((ushort)(bpa + 1)) ^ 0x80) & 0x90) && !TimeOut(800));

  // Now we can change the state of the data lines
  outb(bpa, 0xFF);

  TimeOut(0);//ResetTimeCounter = TRUE;
  // Wait for busy signal to go away
  while (!((inb((ushort)(bpa + 1)) ^ 0x80) & 0x90) && !TimeOut(800));

  // Drive clk line low to get our bit
  outb(bpa, 0xFE);

  // wait 4us or so
  wait_counts(CountVal);

  // Get bit result
  DOWRes = ((inb((ushort)(bpa + 1)) ^ 0x80) & 0x90) ? TRUE : FALSE;

  // Drive pin 14 (ENI\) back high again !!!
  //outb((ushort)(bpa + 2), (uchar)(ControlReg & 0xFD));

  // Drop a couple lines low to disable nand gate
  outb(bpa, NAND_MASK);

  // Spin
  for(i=0;i<2;i++,Wait_us());

  outb((ushort)(bpa + 2), (uchar)(ControlRegGlobal&CONTROL_REG_MASK));

  for(i = 0; i < 10; i++,Wait_us())
    ;

  wait_counts(CountVal);
  wait_counts(CountVal);
  Wait_us();
  Wait_us();
  // Return 1-wire result
  return DOWRes;
}
////////////////////////////////////////////////////////////////////////////////
uchar SA_DOWBit(uchar tbit)
{
   // Return sampled value
   return DS1481Comm((uchar)(tbit ? RWBIT : W0BIT));
}
////////////////////////////////////////////////////////////////////////////////
static uchar SA_DOWByte(uchar bts)
{
  uchar i,
        brecv = 0;

  // Call SA_DOWBit 8 times to transfer entire byte
  for (i = 0; i < 8; i++)
  {
    brecv >>= 1;

    // Smush bit into byte
    brecv |= (uchar)SA_DOWBit((uchar) (bts & 1)) ? 0x80 : 0;
    bts >>= 1;
  }

  // Return result sampled on 1-wire bus
  return brecv;
}
////////////////////////////////////////////////////////////////////////////////
static uchar SA_DOWReset(void)
{
  // Sampling a low => presence detected => success
  return DS1481Comm(RESET) ^ 1;
}
////////////////////////////////////////////////////////////////////////////////
uchar TimeOut(ushort nCycles)// 0 - Resets Counter, otherwise the counter is
{                            // incremented and compared to nCycles. If
  ushort mult = 1;           // counter < nCycles  -> return FALSE,  else if
                             // counter >= nCycles -> return TRUE and reset the
                             // counter to 0.
  if(!nCycles)// just reset timecounter
  {
    ResetTimeCounter=TRUE;
    return TRUE;
  }

  if(ResetTimeCounter)
  {
    ResetTimeCounter = FALSE;
    TimeCounter = 0;
  }

  if(nCycles > 0)
    mult = nCycles;

  wait_counts(CountVal);// 4-6us

  if((++TimeCounter) >= mult)
  {
    TimeCounter = 0;
    return TRUE;
  }

  return FALSE;
}
////////////////////////////////////////////////////////////////////////////////
// Initialization Code & Data Segs.
// goes away after init.
#pragma VxD_ICODE_SEG
#pragma VxD_IDATA_SEG
////////////////////////////////////////////////////////////////////////////////
DWORD _stdcall VSAuthD_Dynamic_Init(void)
{
  GetCalibration();
  return(VXD_SUCCESS);
}
////////////////////////////////////////////////////////////////////////////////
// VSAuthD.c
