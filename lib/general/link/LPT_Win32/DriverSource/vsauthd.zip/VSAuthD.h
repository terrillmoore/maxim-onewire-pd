// vsauthd.h

//
//  Copyright (C) 1995 Dallas Semiconductor Corporation.
//  All rights Reserved. Printed in U.S.A.
//  This software is protected by copyright laws of
//  the United States and of foreign countries.
//  This material may also be protected by patent laws of the United States
//  and of foreign countries.
//  This software is furnished under a license agreement and/or a
//  nondisclosure agreement and may only be used or copied in accordance
//  with the terms of those agreements.
//  The mere transfer of this software does not imply any licenses
//  of trade secrets, proprietary technology, copyrights, patents,
//  trademarks, maskwork rights, or any other form of intellectual
//  property whatsoever. Dallas Semiconductor retains all ownership rights.
//

/*
 $Workfile: VSAuthD.h $
 $Revision: 8 $
 $Date: 6/16/02 4:33p $
 $Author: Shughes $
 $Modtime: 6/16/02 4:32p $
 $Log: /Drivers/VSAuthD/VSAuthD.h $
* 
* 8     6/16/02 4:33p Shughes
* 
* 7     4/30/02 4:33p Shughes
* 
* 6     12/02/99 5:45a Tomc
* 
* 5     10/13/99 1:22p Tomc
* 
* 4     10/13/99 11:40a Tomc
* 
* 3     12/22/98 8:58a Tomc
* 
* 2     12/21/98 1:01p Tomc
*/


#ifndef _VSAUTHD_H_
#define _VSAUTHD_H_

#include "sauth95.h"

#define outb(P,D)    outcall((P),(D))
#define inb(P)       incall((P))

#define RESET      0xFD     // Set data lines to 0xFD to perform a reset
#define W0BIT      0xFE     // Set data lines to 0xFE to send a write 0
#define RWBIT      0xFF     // Set data lines to 0xFF to send a write 1 or read 0/1
#define DOW_ACCESS 0x55

#define NAND_MASK         0xAB
#define CONTROL_REG_MASK  0x1F

#define SPPMODE_AND_MASK 0x1F
#define ECPMODE_OR_MASK 0x30

#define ECPPORT_ECR_OFFSET 0x402

#define MAX_WAIT   4000   

typedef DIOCPARAMETERS *LPDIOC;

static uchar SA_DOWBit            (uchar);// Internal functions
static uchar SA_DOWByte           (uchar);
static uchar SA_DOWReset          (void);
static uchar SA_DOWToggleOverDrive(void);
static uchar SA_DOWCheckBusy      (void);
static uchar SA_DOWCheckOverdrive (void);
static uchar SA_DOWFastAccess     (uchar *RomId);
static uchar SA_DOWFastByte       (uchar DataByte);

static uchar DS1481Comm (uchar);
static uchar TimeOut    (ushort);
static void  wait_counts(ushort);
static void  GetTiming(ushort *, ushort *);

#endif // _VSAUTHD_H_

